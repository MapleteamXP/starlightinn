// ----------------------------------------------------------------------------
// KawaiiCool Island - Core Framework
// ----------------------------------------------------------------------------
// GameEvents.cs - All game event definitions for the type-safe EventBus
// ----------------------------------------------------------------------------
// Defines the IGameEvent marker interface and all event structs used across
// the game's systems. Events are lightweight value-type structs for zero-allocation
// message passing via the EventBus system.
// ----------------------------------------------------------------------------

using UnityEngine;
using Unity.Netcode;

namespace KawaiiCoolIsland.Core.Events
{
    #region Marker Interface

    /// <summary>
    /// Marker interface for all game events. Event structs implementing this
    /// interface can be published and subscribed to via the <see cref="EventBus"/>.
    /// </summary>
    public interface IGameEvent { }

    #endregion

    #region Avatar & Customization Events

    /// <summary>
    /// Fired when a player changes their avatar appearance (clothing, accessory, etc.).
    /// </summary>
    public struct AvatarChangedEvent : IGameEvent
    {
        /// <summary>The unique identifier of the player whose avatar changed.</summary>
        public string PlayerId;

        /// <summary>The category of part that changed (e.g., "Hat", "Shirt", "Shoes").</summary>
        public string PartCategory;

        /// <summary>The new item label/identifier applied.</summary>
        public string NewLabel;
    }

    /// <summary>
    /// Fired when a player changes their avatar's body properties (skin tone, height, etc.).
    /// </summary>
    public struct AvatarBodyChangedEvent : IGameEvent
    {
        /// <summary>The unique identifier of the player.</summary>
        public string PlayerId;

        /// <summary>The body property that changed (e.g., "SkinTone", "Height").</summary>
        public string PropertyName;

        /// <summary>The new value of the property.</summary>
        public float NewValue;
    }

    #endregion

    #region Inventory & Economy Events

    /// <summary>
    /// Fired when the local player's inventory contents change.
    /// </summary>
    public struct InventoryChangedEvent : IGameEvent
    {
        /// <summary>The unique item identifier that changed.</summary>
        public string ItemId;

        /// <summary>The new quantity of the item after the change.</summary>
        public int Quantity;

        /// <summary>The delta amount (positive for gain, negative for loss).</summary>
        public int Delta;
    }

    /// <summary>
    /// Fired when the player gains a new item they didn't previously own.
    /// </summary>
    public struct ItemAcquiredEvent : IGameEvent
    {
        /// <summary>The unique item identifier that was acquired.</summary>
        public string ItemId;

        /// <summary>Display name of the acquired item.</summary>
        public string ItemName;

        /// <summary>Whether the item is of rare quality (for special effects).</summary>
        public bool IsRare;
    }

    /// <summary>
    /// Fired when any currency balance changes (Coins, Gems, StarDust, etc.).
    /// </summary>
    public struct CurrencyChangedEvent : IGameEvent
    {
        /// <summary>The currency type identifier (e.g., "Coins", "Gems", "StarDust").</summary>
        public string CurrencyType;

        /// <summary>The new total balance after the change.</summary>
        public int NewBalance;

        /// <summary>The delta amount (positive for gain, negative for spend).</summary>
        public int Delta;
    }

    /// <summary>
    /// Fired when a transaction (purchase, sale, trade) completes.
    /// </summary>
    public struct TransactionCompletedEvent : IGameEvent
    {
        /// <summary>Unique transaction identifier.</summary>
        public string TransactionId;

        /// <summary>Whether the transaction was successful.</summary>
        public bool Success;

        /// <summary>Human-readable result message.</summary>
        public string Message;
    }

    #endregion

    #region Social & Chat Events

    /// <summary>
    /// Fired when a chat message is received from any channel.
    /// </summary>
    public struct ChatMessageEvent : IGameEvent
    {
        /// <summary>The unique sender identifier.</summary>
        public string SenderId;

        /// <summary>The display name of the sender.</summary>
        public string SenderName;

        /// <summary>The chat message content.</summary>
        public string Message;

        /// <summary>The channel identifier (0=Global, 1=Island, 2=Party, 3=Whisper).</summary>
        public int Channel;
    }

    /// <summary>
    /// Fired when the local player receives a friend request.
    /// </summary>
    public struct FriendRequestEvent : IGameEvent
    {
        /// <summary>The player ID sending the friend request.</summary>
        public string SenderId;

        /// <summary>The display name of the requesting player.</summary>
        public string SenderName;
    }

    /// <summary>
    /// Fired when a friend's online status changes.
    /// </summary>
    public struct FriendStatusChangedEvent : IGameEvent
    {
        /// <summary>The friend's player ID.</summary>
        public string FriendId;

        /// <summary>True if the friend is now online.</summary>
        public bool IsOnline;

        /// <summary>The current location of the friend if online.</summary>
        public string CurrentLocation;
    }

    #endregion

    #region Multiplayer & Player Events

    /// <summary>
    /// Fired when a new player joins the current multiplayer session.
    /// Uses Unity Netcode types for networked scenarios.
    /// </summary>
    public struct PlayerJoinedEvent : IGameEvent
    {
        /// <summary>The unique player identifier (may be a Netcode ClientId string).</summary>
        public string PlayerId;

        /// <summary>The display name of the player who joined.</summary>
        public string PlayerName;

#if UNITY_NETCODE_EXISTS
        /// <summary>The Netcode client ID if available.</summary>
        public ulong ClientId;
#endif
    }

    /// <summary>
    /// Fired when a player leaves the current multiplayer session.
    /// </summary>
    public struct PlayerLeftEvent : IGameEvent
    {
        /// <summary>The unique identifier of the player who left.</summary>
        public string PlayerId;

        /// <summary>The display name of the player who left.</summary>
        public string PlayerName;

        /// <summary>The reason for disconnection if known.</summary>
        public string Reason;
    }

    /// <summary>
    /// Fired when the local player's network connection state changes.
    /// </summary>
    public struct ConnectionStateChangedEvent : IGameEvent
    {
        /// <summary>The new connection state (0=Disconnected, 1=Connecting, 2=Connected).</summary>
        public int NewState;

        /// <summary>Additional information about the state change.</summary>
        public string Info;
    }

    #endregion

    #region Island & World Events

    /// <summary>
    /// Fired when an object is placed on the player's island.
    /// </summary>
    public struct IslandObjectPlacedEvent : IGameEvent
    {
        /// <summary>The unique identifier of the placed object instance.</summary>
        public string ObjectId;

        /// <summary>The world position where the object was placed.</summary>
        public Vector3 Position;

        /// <summary>The world rotation applied to the object.</summary>
        public Quaternion Rotation;

        /// <summary>The item data ID of the placed object.</summary>
        public string ItemDataId;

        /// <summary>The player ID who placed the object.</summary>
        public string PlacedByPlayerId;
    }

    /// <summary>
    /// Fired when an island object is removed or picked up.
    /// </summary>
    public struct IslandObjectRemovedEvent : IGameEvent
    {
        /// <summary>The unique identifier of the removed object instance.</summary>
        public string ObjectId;

        /// <summary>The player ID who removed the object.</summary>
        public string RemovedByPlayerId;
    }

    /// <summary>
    /// Fired when the island's environment (time of day, weather) changes.
    /// </summary>
    public struct IslandEnvironmentChangedEvent : IGameEvent
    {
        /// <summary>Time of day in hours (0-24).</summary>
        public float TimeOfDay;

        /// <summary>Weather state (0=Clear, 1=Cloudy, 2=Rain, 3=Snow).</summary>
        public int WeatherState;
    }

    #endregion

    #region Minigame Events

    /// <summary>
    /// Fired when a minigame's state changes (Waiting, Playing, Ended, etc.).
    /// </summary>
    public struct MinigameStateChangedEvent : IGameEvent
    {
        /// <summary>The unique minigame identifier.</summary>
        public string MinigameId;

        /// <summary>The new state (0=Inactive, 1=Waiting, 2=Countdown, 3=Playing, 4=Ended).</summary>
        public int NewState;

        /// <summary>Time remaining in current phase if applicable.</summary>
        public float TimeRemaining;
    }

    /// <summary>
    /// Fired when a minigame score update occurs.
    /// </summary>
    public struct MinigameScoreEvent : IGameEvent
    {
        /// <summary>The minigame identifier.</summary>
        public string MinigameId;

        /// <summary>The player ID whose score changed.</summary>
        public string PlayerId;

        /// <summary>The new score value.</summary>
        public int NewScore;

        /// <summary>The point delta from the previous score.</summary>
        public int ScoreDelta;
    }

    /// <summary>
    /// Fired when a minigame round/match completes with final results.
    /// </summary>
    public struct MinigameCompletedEvent : IGameEvent
    {
        /// <summary>The minigame identifier.</summary>
        public string MinigameId;

        /// <summary>The local player's final score.</summary>
        public int FinalScore;

        /// <summary>The local player's final rank (1-based).</summary>
        public int FinalRank;

        /// <summary>XP awarded for participation.</summary>
        public int XPAwarded;

        /// <summary>Coins awarded.</summary>
        public int CoinsAwarded;
    }

    #endregion

    #region Progression & Achievement Events

    /// <summary>
    /// Fired when the player's level increases.
    /// </summary>
    public struct LevelUpEvent : IGameEvent
    {
        /// <summary>The new player level.</summary>
        public int NewLevel;

        /// <summary>The previous player level.</summary>
        public int PreviousLevel;

        /// <summary>New features/unlocks granted at this level.</summary>
        public string[] Unlocks;
    }

    /// <summary>
    /// Fired when an achievement is unlocked.
    /// </summary>
    public struct AchievementUnlockedEvent : IGameEvent
    {
        /// <summary>The achievement identifier.</summary>
        public string AchievementId;

        /// <summary>The display name of the achievement.</summary>
        public string AchievementName;

        /// <summary>The achievement description text.</summary>
        public string Description;
    }

    /// <summary>
    /// Fired when a daily quest objective is completed.
    /// </summary>
    public struct QuestCompletedEvent : IGameEvent
    {
        /// <summary>The quest identifier.</summary>
        public string QuestId;

        /// <summary>The quest display name.</summary>
        public string QuestName;

        /// <summary>Rewards granted for completion.</summary>
        public string[] RewardIds;
    }

    #endregion

    #region System & Lifecycle Events

    /// <summary>
    /// Fired when the game state changes (Boot, MainMenu, Island, etc.).
    /// </summary>
    public struct GameStateChangedEvent : IGameEvent
    {
        /// <summary>The previous game state.</summary>
        public GameState PreviousState;

        /// <summary>The new game state.</summary>
        public GameState NewState;
    }

    /// <summary>
    /// Fired when a save operation completes (success or failure).
    /// </summary>
    public struct SaveCompletedEvent : IGameEvent
    {
        /// <summary>Whether the save was successful.</summary>
        public bool Success;

        /// <summary>The key that was saved.</summary>
        public string Key;

        /// <summary>Error message if save failed.</summary>
        public string ErrorMessage;
    }

    /// <summary>
    /// Fired when a load operation completes.
    /// </summary>
    public struct LoadCompletedEvent : IGameEvent
    {
        /// <summary>Whether the load was successful.</summary>
        public bool Success;

        /// <summary>The key that was loaded.</summary>
        public string Key;

        /// <summary>Error message if load failed.</summary>
        public string ErrorMessage;
    }

    /// <summary>
    /// Fired when the input device type changes (Keyboard, Touch, Gamepad).
    /// </summary>
    public struct InputDeviceChangedEvent : IGameEvent
    {
        /// <summary>The new input device type (0=KeyboardMouse, 1=Touch, 2=Gamepad).</summary>
        public int DeviceType;
    }

    #endregion
}
