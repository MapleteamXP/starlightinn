# KawaiiCool Island

> The Ultimate Cross-Platform Social Hangout Game
> 
> A kawaii-cool virtual world where friends gather, customize avatars, design dream islands, play minigames, and make unforgettable memories.

---

## Project Overview

| Property | Value |
|----------|-------|
| **Engine** | Unity 2023.2+ LTS |
| **Render Pipeline** | Universal Render Pipeline (URP) 2D |
| **Platforms** | Android, iOS, Windows, macOS |
| **Networking** | Netcode for GameObjects + Unity Relay |
| **Backend** | Firebase + PlayFab hybrid |
| **Codebase** | 80 C# files, 45,000+ lines |

---

## System Architecture

```
+-------------------------------------------------------------+
|                    KAWAIICOOL ISLAND                        |
|                 Cross-Platform Social World                 |
+-------------------------------------------------------------+
|  CLIENT (Unity 2023.2 LTS + URP 2D)                        |
|  +------------------+  +------------------+                 |
|  |   CORE SYSTEMS   |  |  GAME SYSTEMS    |                 |
|  | - Bootstrapper   |  | - Avatar Ctrl    |                 |
|  | - Event Bus      |  | - Island Editor  |                 |
|  | - Save Manager   |  | - Minigames (5)  |                 |
|  | - Game Manager   |  | - Inventory      |                 |
|  | - Object Pool    |  | - Shop + Economy |                 |
|  | - CoroutineUtils |  | - Daily Rewards  |                 |
|  +------------------+  +------------------+                 |
|  +------------------+  +------------------+                 |
|  | MULTIPLAYER      |  | SOCIAL FEATURES  |                 |
|  | - NetworkManager |  | - Chat System    |                 |
|  | - NetworkedPlayer|  | - Chat Bubbles   |                 |
|  | - Room Manager   |  | - Emote Reactions|                 |
|  | - Proximity Chat |  | - Slash Commands |                 |
|  | - Scene Loader   |  | - Profanity Filter|                |
|  +------------------+  +------------------+                 |
|  +------------------+  +------------------+                 |
|  | UI FRAMEWORK     |  | AUDIO SYSTEM     |                 |
|  | - UIManager      |  | - Dynamic Music  |                 |
|  | - UIPanel Base   |  | - SFX Manager    |                 |
|  | - Transitions    |  | - Ambient Audio  |                 |
|  | - Responsive     |  | - Voice Chat     |                 |
|  | - Touch Controls |  | - Mixer Setup    |                 |
|  | - Safe Area      |  | - Trigger Zones  |                 |
|  +------------------+  +------------------+                 |
+-------------------------------------------------------------+
|  BACKEND LAYER                                              |
|  +------------------+  +------------------+                 |
|  | FIREBASE         |  | PLAYFAB          |                 |
|  | - Authentication |  | - Economy        |                 |
|  | - Analytics      |  | - Cloud Save     |                 |
|  | - Crashlytics    |  | - Leaderboards   |                 |
|  | - Remote Config  |  | - Inventory      |                 |
|  | - Cloud Messaging|  | - Friends        |                 |
|  +------------------+  +------------------+                 |
|  +------------------+  +------------------+                 |
|  | CUSTOM REST API  |  | SERVER VALIDATION|                 |
|  | - Player Profiles|  | - Purchase Check |                 |
|  | - Friends        |  | - Anti-Cheat     |                 |
|  | - Trading        |  | - State Verify   |                 |
|  | - Reporting      |  | - Heartbeat      |                 |
|  +------------------+  +------------------+                 |
+-------------------------------------------------------------+
```

---

## Quick Start

### Prerequisites

- **Unity Hub** with Unity 2023.2.x LTS installed
- **Platform modules**: Android Build Support, iOS Build Support (Mac only)
- **IDE**: Visual Studio 2022, VS Code, or Rider
- Optional: Firebase SDK, PlayFab SDK (for backend features)

### Setup Instructions

1. **Clone or extract** this project to your desired location
2. **Open Unity Hub** → Add project → Select the `KawaiiCoolIsland` folder
3. **Wait for Unity** to import and compile all scripts (first import may take 5-10 minutes)
4. **Open the Boot scene** at `Assets/_Project/Scenes/Boot.unity`
5. **Press Play** to run the game

### Required Package Setup

The following packages will auto-install via the Package Manager:

| Package | Version | Purpose |
|---------|---------|---------|
| URP | 14.0.11 | 2D rendering pipeline |
| Netcode for GameObjects | 1.8.1 | Multiplayer networking |
| Input System | 1.7.0 | Cross-platform input |
| 2D Animation | 9.1.0 | Sprite rigging & swap |
| TextMeshPro | 3.0.9 | UI text rendering |
| Unity Transport | 2.1.0 | Network transport layer |

### Optional SDK Integration

For full backend functionality, install:

**Firebase** (via Unity Package Manager or external SDK):
```
Window > Package Manager > Add package from git URL
com.google.firebase.app
com.google.firebase.auth
com.google.firebase.analytics
com.google.firebase.crashlytics
com.google.firebase.remote-config
com.google.firebase.messaging
```

**PlayFab** (via Unity Asset Store or Package Manager):
```
Window > Package Manager > Packages: In Project
com.playfab.unitysdk
```

After installing, add these symbols to **Player Settings > Other Settings > Scripting Define Symbols**:
- `FIREBASE` - Enable Firebase integration
- `PLAYFAB` - Enable PlayFab integration

---

## Core Systems

### 1. Avatar System

**Files**: `Assets/_Project/Scripts/Avatar/` (7 files, 2,372 lines)

- **Modular sprite layering**: 9 render layers (Body → Shoes → Bottom → Top → HairBack → Head → HairFront → Accessory1 → Accessory2)
- **Runtime swapping**: Swap clothing, hair, accessories via `SpriteResolver.SetCategoryAndLabel()`
- **Outfit presets**: Save/load complete outfits as `OutfitData` ScriptableObjects
- **Emote system**: 20+ emotes with animation, SFX, looping, and movement-lock options
- **Color customization**: Hair dye, skin tone, eye color, clothing tints via `MaterialPropertyBlock`
- **Preview system**: Rotatable preview with thumbnail capture for UI

**Key Classes**:
```
AvatarController      - Main avatar controller
AvatarPartData        - ScriptableObject for clothing/accessory items
OutfitData            - Complete outfit preset
EmotePlayer           - Emote playback with coroutines
ColorCustomization    - Runtime color tinting
```

### 2. Island Editor

**Files**: `Assets/_Project/Scripts/Island/` (8 files, 2,272 lines)

- **Dual placement modes**: Snap-to-grid for tiles, free placement for decorations
- **Object manipulation**: Pick up, rotate (90° steps), scale (with min/max bounds), drag-and-drop
- **Visual feedback**: Ghost preview with valid/invalid color coding
- **Tilemap integration**: Paint ground and decoration layers, flood fill, bulk operations
- **Multi-slot save**: Up to 10 save slots with JSON serialization
- **Y-depth sorting**: Automatic sorting order based on Y position for 2.5D depth
- **Cloud sync ready**: Stubs for PlayFab cloud save integration

**Key Classes**:
```
IslandEditor      - Main editor controller
PlaceableObject   - Prefab component with placement rules
PlacedObject      - Runtime placed object
TilemapManager    - Tile painting and querying
IslandSaveManager - Save/load with multiple slots
```

### 3. Multiplayer System

**Files**: `Assets/_Project/Scripts/Multiplayer/` (8 files, 3,565 lines)

- **Netcode for GameObjects**: Official Unity networking with NetworkVariables and RPCs
- **Owner-authoritative movement**: Client controls their own position, others interpolate
- **Unity Relay**: NAT traversal for internet multiplayer without port forwarding
- **Room system**: 5 room types (Hub, Island, Minigame, Private, Event) with capacity limits
- **Proximity chat**: Distance-based text/voice chat with configurable range
- **Smooth interpolation**: Vector3.Lerp for remote player movement, ClientNetworkTransform
- **Connection quality**: Real-time ping/packet loss monitoring with visual indicator

**Key Classes**:
```
KawaiiNetworkManager  - Network manager wrapper
NetworkedPlayer       - Player network behavior
RoomManager           - Room/lobby management
ProximityChat         - Proximity-based chat
NetworkSceneLoader    - Networked scene transitions
```

### 4. Minigame Framework

**Files**: `Assets/_Project/Scripts/Minigames/` (7 files, 6,956 lines)

Abstract base class with 5 implementations:

| Minigame | Description | Players | Duration |
|----------|-------------|---------|----------|
| **Rhythm Dance** | 4-lane rhythm game with combo/fever system | 1-4 | 2-3 min |
| **Fashion Voting** | Dress to theme, vote on outfits | 2-4 | 2-3 min |
| **Coin Rush** | Collect coins in arena with power-ups | 1-4 | 1-2 min |
| **Trivia** | Timed quiz with streak bonuses | 1-4 | 3-5 min |
| **Hide & Seek** | Hiders vs seekers with detection cone | 2-4 | 2-3 min |

**Features**:
- State machine: Inactive → Waiting → Countdown → Playing → GameOver
- Coroutine-based timing (no Update spaghetti)
- Per-player scoring with combos, streaks, and multipliers
- Reward distribution at game end
- Network-synced for multiplayer

### 5. Inventory & Shop

**Files**: `Assets/_Project/Scripts/Inventory/` (8 files, 4,256 lines)

- **Grid-based inventory**: Drag-and-drop with touch and mouse support
- **Item system**: 5 rarity tiers, 7 categories, stacking with configurable limits
- **Virtual economy**: Coins (soft), Gems (hard), Tickets (event) currencies
- **Daily shop rotation**: Server-time based with featured items and events
- **Daily rewards**: 7-day streak system with escalating rewards
- **Currency display**: Animated HUD with counting effects

### 6. Chat System

**Files**: `Assets/_Project/Scripts/Chat/` (9 files, 5,312 lines)

- **6 chat channels**: World, Proximity, Island, Party, System, Whisper
- **World-space bubbles**: Chat messages appear above player heads with fade animations
- **Profanity filter**: Leet-speak aware filtering with configurable word list
- **Emote reactions**: Right-click messages to add emoji reactions
- **Slash commands**: `/w`, `/mute`, `/block`, `/party`, `/emote`, `/help`, etc.
- **Typing indicators**: "Player is typing..." with animated dots
- **Message moderation**: Mute, block, report with category selection

### 7. UI Framework

**Files**: `Assets/_Project/Scripts/UI/` (9 files, 5,803 lines)

- **Responsive design**: Auto-detects mobile/desktop with layout switching
- **Canvas management**: 4-layer system (Main/Overlay/Popup/Tooltip)
- **12 animation types**: Fade, slide (4 directions), scale, bounce, shake, punch
- **Touch controls**: On-screen joystick, action buttons, pinch-to-zoom camera
- **Safe area**: Automatic notch/home indicator padding
- **Toast notifications**: Queued toasts with type-based styling

### 8. Audio System

**Files**: `Assets/_Project/Scripts/Audio/` (7 files, 4,334 lines)

- **Dynamic music**: 4 synchronized layers that crossfade based on game state
- **SFX pooling**: Object pool prevents garbage collection from AudioSource creation
- **Spatial audio**: Distance-based attenuation for 2D world
- **Ambient soundscapes**: Time-of-day and weather-based ambient audio
- **AudioMixer snapshots**: Smooth transitions between gameplay states
- **Voice chat stub**: Vivox/Photon Voice compatible API

### 9. Backend Integration

**Files**: `Assets/_Project/Scripts/Backend/` (7 files, 4,974 lines)

- **Firebase**: Auth (anonymous/email/social), Analytics, Crashlytics, Remote Config, Push Notifications
- **PlayFab**: Economy, Cloud Save, Leaderboards, Inventory, Friends, CloudScript
- **REST API**: Player profiles, friends, trading, reporting, server time
- **Server validation**: Anti-cheat purchase validation, state verification
- **Cloud save sync**: Auto-sync with conflict resolution

---

## Project Structure

```
KawaiiCoolIsland/
├── Assets/
│   └── _Project/
│       ├── Scripts/
│       │   ├── Core/           # 10 files - Framework foundation
│       │   ├── Avatar/         # 7 files  - Character system
│       │   ├── Island/         # 8 files  - Island editor
│       │   ├── Multiplayer/    # 8 files  - Netcode multiplayer
│       │   ├── UI/             # 9 files  - UI framework
│       │   ├── Chat/           # 9 files  - Chat system
│       │   ├── Minigames/      # 7 files  - Minigame framework
│       │   ├── Inventory/      # 8 files  - Inventory & shop
│       │   ├── Audio/          # 7 files  - Audio system
│       │   └── Backend/        # 7 files  - Backend integration
│       ├── ScriptableObjects/  # Data definitions
│       ├── Prefabs/            # Prefab templates
│       ├── Scenes/             # Game scenes
│       ├── Settings/           # URP, Input, AudioMixer
│       └── Sprites/            # 2D art assets
├── Packages/
│   └── manifest.json           # Unity package dependencies
└── README.md                   # This file
```

---

## Build Configuration

### Platform-Specific Settings

| Platform | Target FPS | Bloom | Texture | Input |
|----------|-----------|-------|---------|-------|
| Android (Mid) | 30 | Quarter | Half Res | Touch |
| Android (High) | 60 | Half | Full | Touch |
| iOS | 60 | Half | Full | Touch |
| Windows | 144 | Full | Full | KBM + Gamepad |
| macOS | 120 | Full | Full | KBM + Gamepad |

### Quality Levels

1. **Mobile Low**: No bloom, simple shaders, no post-processing
2. **Mobile High**: Quarter bloom, basic post-processing
3. **Desktop**: Full bloom, all post-processing, HDR enabled

---

## Controls

### Mobile (Touch)
- **Left side**: Virtual joystick for movement
- **Right side**: Action buttons (Interact, Emote, Jump)
- **Tap**: Interact with objects
- **Pinch**: Zoom camera
- **Drag (right side)**: Pan camera

### Keyboard & Mouse
- **WASD / Arrow keys**: Movement
- **E**: Interact
- **Space**: Jump / Action
- **Tab**: Toggle chat
- **I**: Inventory
- **B**: Shop
- **C**: Character customization
- **Esc**: Close panels / Pause

### Gamepad
- **Left Stick**: Movement
- **A / Cross**: Interact / Confirm
- **B / Circle**: Cancel / Close
- **X / Square**: Emote
- **Y / Triangle**: Inventory
- **D-Pad**: Navigate UI
- **Start**: Pause menu

---

## Architecture Decisions

### Why Netcode for GameObjects (not Mirror/FishNet)?
- Official Unity support and documentation
- Best integration with Unity Gaming Services (Relay, Lobby)
- Sufficient for casual social games (not competitive FPS)
- Future-proof with Unity's networking roadmap

### Why Firebase + PlayFab Hybrid?
- Firebase: Best-in-class auth, analytics, and crash reporting
- PlayFab: Purpose-built for game economies and live-ops
- Both have generous free tiers for indie development
- Clean separation: general services vs game-specific

### Why Custom Tweening (not DOTween)?
- Zero external dependencies
- Full source code control
- Smaller build size
- Tailored to project's specific needs

---

## Performance Targets

| Metric | Mobile Target | Desktop Target |
|--------|--------------|----------------|
| Draw Calls | < 100 | < 200 |
| SetPass Calls | < 50 | < 100 |
| Texture Memory | < 128 MB | < 512 MB |
| GC Alloc/Frame | < 1 KB | < 1 KB |
| Load Time | < 5s | < 3s |
| Scene Transition | < 2s | < 1s |

---

## Development Team

Built with a multi-agent orchestration system featuring:
- 1 Core Systems Architect
- 1 Avatar & Animation Specialist
- 1 Island Editor Specialist
- 1 Multiplayer Networking Specialist
- 1 UI/UX Framework Specialist
- 1 Chat System Specialist
- 1 Minigame Framework Specialist
- 1 Inventory & Economy Specialist
- 1 Audio Systems Specialist
- 1 Backend Integration Specialist

---

## License

This project is provided as a starting template for your own kawaii social world game. Feel free to modify, extend, and build upon it. The architecture follows Unity and industry best practices to provide a solid foundation for production development.

---

## Roadmap

### Phase 1 (Current)
- [x] Core framework and architecture
- [x] Avatar customization system
- [x] Island editor with save/load
- [x] Multiplayer with Netcode
- [x] UI framework
- [x] Chat system
- [x] 5 minigame implementations
- [x] Inventory and shop
- [x] Audio system
- [x] Backend integration stubs

### Phase 2
- [ ] Clan/guild system
- [ ] Player-to-player trading
- [ ] Seasonal events framework
- [ ] Battle pass system
- [ ] Advanced analytics dashboard
- [ ] Moderation tools
- [ ] User-generated content

### Phase 3
- [ ] Mobile push notifications
- [ ] Cross-platform friend sync
- [ ] Advanced anti-cheat
- [ ] Server authoritative multiplayer
- [ ] Custom server infrastructure
- [ ] Esports tournament system

---

*Built with love, sparkles, and a whole lot of coroutines.*
